#### **NoteSaver**



A quick workflow guide for logging AR follow-up documentation. Built as a plain HTML, CSS, and JavaScript app, no installation, no hosting, no build step. Just open the file in a browser.



What it does:

NoteSaver helps log claim follow-up notes in a consistent format and keeps a running history of invoices worked, all stored locally in the browser.



Main form:
Date of Service (DOS) — required date field
Group# — required dropdown, 137 or 138
Invoice Number — required, numbers only, sized for 11-12 digit invoice numbers
Problem / Action Taken / Resolution — required text area, with a short guide above it on what to enter

A running timer starts once you begin filling out the form, so you can track how long each entry takes.



Done:

Clicking Done validates that all required fields are filled, then shows a formatted output line:

GBC/CONIFER/TPF/DOS: (date)/INV: (group)x(invoice)/(problem/action taken/resolution text)

From that output screen you can:

Copy the formatted line to your clipboard
Reset to return to a blank form for the next entry



Work log:

A small number badge in the header counts how many entries you've completed. Click the number to open the invoice history page, which lists every invoice number logged so far (most recent on top). Clicking an invoice in that list copies it to your clipboard. There's a Clear History option to wipe the log and reset the counter back to 0.



Timely Filing Calculator:

A separate calculator page (opened from the icon in the header) checks whether a claim is within or past its timely filing window:



Enter the relevant dates (Date of Service, and Prv./Lat. Processed Dates if applicable)
Pick a filing limit (30, 45, 60, 90, 120, 180, 365 days) or enter a custom number of days
The result is color-coded:
Within Timely Filing — green
Past Timely Filing — red
Unable to Process (conflicting or incomplete dates) — pastel yellow, with an alert icon
Invalid Date Provided — gray



How to use it:
Download or extract the NoteSaver file(s) to any folder.
Double-click NoteSaber html file to open it in your browser.
No internet connection, installation, or server is required.

Data storage

All data (work-done count, invoice history) is saved locally in your browser's storage. It stays on your machine and does not sync or upload anywhere. Clearing your browser data will also clear this history.



Notes:
Color theme: burgundy (
#800020), cream (
#FFFDD0), white, and black.



##### **Attestation**



This app was built by Lemuel Jan Suico, for team's internal use, with the sole intent of helping streamline our everyday AR follow-up documentation workflow. It contains no viruses, malware, or any code intended to cause harm, data loss, or financial loss to the business.



It's a plain HTML/CSS/JavaScript file with no installer, no background processes, and no external network calls. All data it collects (work-done count, invoice history) stays saved locally in the browser and is never sent anywhere.



As with any file received from a coworker, feel free to run it through your standard antivirus/endpoint scan before use — that's good practice regardless of the source.



I, Lemuel Jan Suico, take full personal responsibility and liability for this application and its contents. If it is found to contain any malicious code, cause any harm, data loss, or financial loss to the business, or otherwise misrepresent what is stated above, I accept full accountability for those consequences.


###### — Lemuel Jan Suico

